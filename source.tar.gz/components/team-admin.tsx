'use client';
import { FormEvent, useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import type { Member } from '@/lib/types';
import { formatDateTime } from '@/lib/utils';

export function TeamAdmin({ members, onChanged }: { members: Member[]; onChanged: () => Promise<void> }) {
  const [memberId, setMemberId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [runs, setRuns] = useState<any[]>([]);
  const selected = members.find(m => m.id === memberId);
  async function loadRuns() {
    const { data } = await createClient().from('backup_runs').select('*').order('started_at', { ascending: false }).limit(8);
    setRuns(data || []);
  }
  useEffect(() => { loadRuns(); }, []);
  async function invite(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError(''); setMessage('');
    const formElement = e.currentTarget;
    const f = new FormData(formElement);
    const payload = { memberId: memberId || undefined, name: String(f.get('name')), email: String(f.get('email')), team: String(f.get('team')), role: String(f.get('role')), employeeId: String(f.get('employeeId')) };
    const response = await fetch('/api/admin/invite', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const result = await response.json(); setBusy(false);
    if (!response.ok) return setError(result.error);
    setMessage(`Invitation sent to ${result.email}. The member can set a password from that email.`);
    setMemberId(''); formElement.reset(); await onChanged();
  }
  async function backup() {
    setBusy(true); setError(''); setMessage('');
    const response = await fetch('/api/backup', { method: 'POST' }); const result = await response.json();
    setBusy(false);
    if (!response.ok) setError(result.error); else setMessage(`Backup complete: ${result.leads} leads and ${result.logs} call logs.`);
    await loadRuns();
  }
  return <>
    <h1 className="page-title">Team & system</h1><p className="subtitle">Invite team members with Supabase Auth and monitor the independent Google Sheets backup.</p>
    {busy && <div className="busy" />}<div className="admin-grid">
      <div className="card"><h2 className="section-title" style={{ marginTop: 0 }}>Invite a member</h2>
        <p className="mute small">Select a seeded agent to attach their email, or choose “New member”. They will receive a secure invitation link.</p>
        <form onSubmit={invite} key={memberId || 'new'}><div className="stack">
          <label className="field">Existing member<select className="select" value={memberId} onChange={e => setMemberId(e.target.value)}><option value="">New member</option>{members.filter(m => !m.auth_user_id).map(m => <option key={m.id} value={m.id}>{m.name} — {m.team}</option>)}</select></label>
          <label className="field">Full name<input className="input" name="name" required defaultValue={selected?.name || ''} /></label>
          <label className="field">Work email<input className="input" name="email" type="email" required defaultValue={selected?.email || ''} placeholder="agent@carrybee.com" /></label>
          <label className="field">Team<select className="select" name="team" defaultValue={selected?.team || 'LQT'}><option>LQT</option><option>Incubation</option><option>Management</option></select></label>
          <label className="field">Role<select className="select" name="role" defaultValue={selected?.role || 'Agent'}><option>Agent</option><option>Team Lead</option><option>Admin</option></select></label>
          <label className="field">Employee ID (optional)<input className="input" name="employeeId" defaultValue={selected?.employee_id || ''} /></label>
          <div className="error">{error}</div>{message && <div className="success small">{message}</div>}
          <button className="btn primary" disabled={busy}>Send email invitation</button>
        </div></form>
      </div>
      <div className="card"><h2 className="section-title" style={{ marginTop: 0 }}>Members</h2><div className="table-wrap" style={{ boxShadow: 'none' }}><table style={{ minWidth: 650 }}><thead><tr><th>Name</th><th>Email</th><th>Team</th><th>Role</th><th>Access</th></tr></thead><tbody>{members.map(m => <tr key={m.id}><td><b>{m.name}</b><br /><span className="mute small">{m.employee_id}</span></td><td>{m.email || 'Not invited'}</td><td>{m.team}</td><td>{m.role}</td><td><span className={`status-dot ${m.auth_user_id ? 'on' : ''}`} />{m.auth_user_id ? 'Active login' : 'Invitation needed'}</td></tr>)}</tbody></table></div></div>
    </div>
    <div className="card"><div className="row"><div className="grow"><h2 className="section-title" style={{ margin: 0 }}>Google Sheets backup</h2><p className="mute small">Scheduled every 15 minutes. The live CRM never waits for this export.</p></div><button className="btn primary" onClick={backup} disabled={busy}>Back up now</button></div>
      <div className="table-wrap" style={{ boxShadow: 'none', marginTop: 15 }}><table style={{ minWidth: 650 }}><thead><tr><th>Started</th><th>Status</th><th>Leads</th><th>Logs</th><th>Triggered by</th><th>Message</th></tr></thead><tbody>{runs.map(r => <tr key={r.id}><td>{formatDateTime(r.started_at)}</td><td><span className={`tag ${r.status === 'success' ? 'good' : r.status === 'failed' ? 'bad' : 'warn'}`}>{r.status}</span></td><td>{r.leads_count}</td><td>{r.calls_count}</td><td>{r.triggered_by}</td><td>{r.message}</td></tr>)}</tbody></table></div>
    </div>
  </>;
}

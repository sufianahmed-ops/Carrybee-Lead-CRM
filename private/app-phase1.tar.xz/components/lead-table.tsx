'use client';
import type { Lead } from '@/lib/types';
import { formatDate, formatDateTime } from '@/lib/utils';

const labels: Record<string, string> = {
  lead_id: 'Lead ID', business_id: 'Business ID', business_name: 'Business', merchant_name: 'Merchant',
  phone_clean: 'Phone', source: 'Source', registration_date: 'Registration date', current_status: 'Status', stage: 'Stage', last_reason: 'Last reason',
  lqt_touches: 'Touches', next_due_date: 'Next due', due_state: 'Due state', current_owner: 'Owner', alert: 'Alert',
  handover_booked_time: 'Booked handover', handover_call_state: 'Handover call', trip_deadline: 'Trip deadline',
  first_trip_date: '1st trip', first_order_date: 'First order', care_end_date: 'Care ends', care_days_left: 'Care days left', last_status_date: 'Status date',
  onboarded_form: 'Onboarded form', first_trip_cid: '1st trip CID', pickup_miss: 'Pickup miss',
  lead_generation: 'Gen',
};
const dateColumns = new Set(['next_due_date', 'trip_deadline', 'first_trip_date', 'first_order_date', 'care_end_date', 'last_status_date', 'registration_date']);

function Cell({ lead, column }: { lead: Lead; column: string }) {
  const raw = lead[column as keyof Lead];
  const value = String(raw ?? '');
  if (column === 'phone_clean') return value ? <a href={`tel:${value}`} onClick={e => e.stopPropagation()}>{value}</a> : null;
  if (column === 'business_name') return <span className="lead-name">{value || lead.merchant_name || '—'}</span>;
  if (column === 'current_status') return <span className="tag status">{value}</span>;
  if (column === 'due_state') return value ? <span className={`tag ${value === 'Overdue' ? 'bad' : value === 'Due Today' ? 'warn' : value === 'Closed' ? 'good' : ''}`}>{value}</span> : null;
  if (column === 'handover_call_state') return value ? <span className={`tag ${value === 'Overdue' ? 'bad' : value === 'Pending' ? 'warn' : 'good'}`}>{value}</span> : null;
  if (column === 'alert') return value ? <span className="tag bad alert-text">{value}</span> : null;
  if (column === 'handover_booked_time') return <>{formatDateTime(lead.handover_booked_time)}</>;
  if (dateColumns.has(column)) return <>{formatDate(value)}</>;
  return <>{value}</>;
}

export function LeadTable({ leads, columns, onOpen, selected, onToggle, onSelectAll }: {
  leads: Lead[]; columns: string[]; onOpen: (id: string) => void;
  selected?: Set<string>; onToggle?: (id: string, checked: boolean) => void; onSelectAll?: (checked: boolean) => void;
}) {
  if (!leads.length) return <div className="table-wrap"><div className="empty">Nothing here right now.</div></div>;
  const bulk = !!selected && !!onToggle;
  return <>
    <div className="table-wrap"><table><thead><tr>
      {bulk && <th><input type="checkbox" aria-label="Select all" checked={leads.length > 0 && leads.every(l => selected.has(l.lead_id))} onChange={e => onSelectAll?.(e.target.checked)} /></th>}
      {columns.map(c => <th key={c}>{labels[c] || c}</th>)}
    </tr></thead><tbody>
      {leads.slice(0, 500).map(lead => <tr key={lead.id} className="clickable" onClick={() => onOpen(lead.lead_id)}>
        {bulk && <td onClick={e => e.stopPropagation()}><input type="checkbox" aria-label={`Select ${lead.lead_id}`} checked={selected.has(lead.lead_id)} onChange={e => onToggle(lead.lead_id, e.target.checked)} /></td>}
        {columns.map(c => <td key={c}><Cell lead={lead} column={c} /></td>)}
      </tr>)}
    </tbody></table></div>
    {leads.length > 500 && <p className="table-note">Showing the first 500. Use search or filters to narrow the list.</p>}
  </>;
}

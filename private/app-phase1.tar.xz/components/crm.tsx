'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { LayoutDashboard, PhoneCall, Workflow, List, Inbox, Heart, XCircle, Badge, Clock3, BookOpen, Database, Search, RefreshCw, Plus, Menu, LogOut, Users, ChevronRight, Sparkles } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { loadBootstrap, loadOneLead, setting } from '@/lib/data';
import type { Bootstrap, Lead, Member } from '@/lib/types';
import { unique } from '@/lib/utils';
import { OLD_ASSIGNMENT_BUSINESS_IDS } from '@/lib/assignment-exclusions';
import { ThemeButton } from './theme-button';
import { LeadTable } from './lead-table';
import { LeadDrawer } from './lead-drawer';
import { AddLead } from './add-lead';
import { TeamAdmin } from './team-admin';

const COLS = {
  lqt: ['lead_id','lead_generation','business_name','merchant_name','phone_clean','source','current_status','last_reason','lqt_touches','next_due_date','due_state','current_owner','alert'],
  inc: ['lead_id','business_name','merchant_name','phone_clean','current_status','current_owner','handover_booked_time','handover_call_state','trip_deadline','next_due_date','due_state','alert'],
  care: ['lead_id','business_name','phone_clean','current_owner','first_order_date','care_end_date','care_days_left','last_reason','next_due_date','due_state'],
  onb: ['lead_id','business_id','business_name','phone_clean','current_status','onboarded_form','first_trip_date','first_trip_cid','pickup_miss','current_owner'],
  final: ['lead_id','business_name','merchant_name','phone_clean','source','current_status','last_reason','last_status_date','current_owner'],
  all: ['lead_id','lead_generation','business_id','business_name','phone_clean','source','registration_date','current_status','stage','current_owner','next_due_date','due_state','alert'],
};
type View = { id: string; title: string; group: string; icon: LucideIcon; columns?: string[]; filter?: (l: Lead) => boolean; final?: boolean; special?: string };

export default function CRM() {
  const router = useRouter();
  const supabase = createClient();
  const [data, setData] = useState<Bootstrap | null>(null);
  const [userId, setUserId] = useState('');
  const [loadError, setLoadError] = useState('');
  const [busy, setBusy] = useState(false);
  const [viewId, setViewId] = useState('dash');
  const [query, setQuery] = useState('');
  const [owner, setOwner] = useState('mine');
  const [source, setSource] = useState('');
  const [generation, setGeneration] = useState('');
  const [registrationFrom, setRegistrationFrom] = useState('');
  const [registrationTo, setRegistrationTo] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [roundRobinAgents, setRoundRobinAgents] = useState<string[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [fromQueue, setFromQueue] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [sideOpen, setSideOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [lastSync, setLastSync] = useState('');
  const me = data?.members.find(m => m.auth_user_id === userId) || null;
  const isLead = !!me && /lead|admin/i.test(me.role);

  const refresh = useCallback(async (showBusy = true) => {
    if (showBusy) setBusy(true);
    try {
      const fresh = await loadBootstrap(supabase);
      setData(fresh); setLastSync(new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })); setLoadError('');
      return fresh;
    } catch (e: any) { setLoadError(e.message || String(e)); throw e; }
    finally { if (showBusy) setBusy(false); }
  }, []);
  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: auth }) => {
      if (!auth.user) return router.replace('/login');
      setUserId(auth.user.id);
      try { await refresh(); } catch { /* displayed below */ }
    });
  }, []);
  useEffect(() => { if (me) setOwner(isLead ? '' : 'mine'); }, [me?.id]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 3500); return () => clearTimeout(t); }, [toast]);

  const views = useMemo<View[]>(() => {
    if (!data) return [];
    const tabsFor = (stages: string[]) => unique(data.rules.filter(r => stages.includes(r.stage)).map(r => r.tab));
    const output: View[] = [
      { id: 'dash', title: 'Dashboard', group: '', icon: LayoutDashboard, special: 'dash' },
      { id: 'queue', title: 'My call queue', group: '', icon: PhoneCall, special: 'queue' },
      { id: 'flow', title: 'How it works', group: '', icon: Workflow, special: 'flow' },
    ];
    tabsFor(['LQT']).forEach(tab => output.push({ id: `tab:${tab}`, title: tab, group: 'Lead Qualification (LQT)', icon: List, columns: COLS.lqt, filter: l => l.tab === tab }));
    if (isLead) output.push({ id: 'new-lqt', title: 'New LQT assignments', group: 'Lead Qualification (LQT)', icon: List, columns: COLS.all, filter: l => l.lead_generation === 'New' && l.source === 'Self Registered' && !l.current_owner && !!l.registration_date && !OLD_ASSIGNMENT_BUSINESS_IDS.has(String(l.business_id || '').trim()) });
    output.push({ id: 'new-gen', title: 'New to LQT', group: 'Lead Qualification (LQT)', icon: Sparkles, columns: COLS.lqt, filter: l => l.lead_generation === 'New' && l.is_final !== 'Yes' });
    output.push({ id: 'old', title: 'Old follow-ups', group: 'Lead Qualification (LQT)', icon: Clock3, columns: COLS.lqt, filter: l => l.lead_generation === 'Old' && l.is_final !== 'Yes' });
    output.push({ id: 'nobid', title: 'Missing Business ID', group: 'Lead Qualification (LQT)', icon: Badge, columns: COLS.lqt, filter: l => l.missing_business_id === 'Missing' });
    tabsFor(['Handover','Incubation']).forEach(tab => output.push({ id: `tab:${tab}`, title: tab, group: 'Incubation', icon: tab === 'Handover Inbox' ? Inbox : tab === 'Care Period' ? Heart : List, columns: tab === 'Care Period' ? COLS.care : COLS.inc, filter: l => l.tab === tab }));
    output.push({ id: 'onb', title: 'Onboarding tracker', group: 'Incubation', icon: Badge, columns: COLS.onb, filter: l => l.in_onboarding_tracker === 'Yes' });
    tabsFor(['Final']).forEach(tab => output.push({ id: `tab:${tab}`, title: tab, group: 'Final statuses', icon: XCircle, columns: COLS.final, filter: l => l.tab === tab, final: true }));
    output.push({ id: 'all', title: 'All leads', group: 'Records', icon: Database, columns: COLS.all, filter: () => true });
    output.push({ id: 'script', title: 'Call script', group: 'Records', icon: BookOpen, special: 'script' });
    if (isLead) output.push({ id: 'team', title: 'Team & system', group: 'Administration', icon: Users, special: 'team' });
    return output;
  }, [data, isLead]);
  const currentView = views.find(v => v.id === viewId) || views[0];
  const currentLead = data?.leads.find(l => l.lead_id === openId) || null;

  function queueRows(sourceData = data) {
    if (!sourceData || !me) return [];
    // Priority order (Phase 1): new-generation work always outranks the old book.
    // 0 handover overdue | 1 NEW first call late | 2 NEW due | 3 NEW fresh | 4 OLD
    return sourceData.leads.filter(l => l.current_owner === me.name && l.priority <= 4)
      .sort((a,b) => a.priority - b.priority || String(a.next_due_date || '9999').localeCompare(String(b.next_due_date || '9999')));
  }
  function go(id: string) { setViewId(id); setSelected(new Set()); setRoundRobinAgents([]); setSideOpen(false); }
  function openLead(id: string, queue = false) { setOpenId(id); setFromQueue(queue); }
  async function saved(previousId: string, next: boolean) {
    // Refresh only the lead that was just written. Reloading the whole workspace
    // (11,000+ leads) after every call was what made Save feel slow.
    let patched: Lead | null = null;
    try { patched = await loadOneLead(supabase, previousId); } catch { /* fall back below */ }
    if (patched) {
      setData(current => {
        if (!current) return current;
        const leads = current.leads.map(l => l.lead_id === patched!.lead_id ? patched! : l);
        return { ...current, leads };
      });
    } else {
      try { await refresh(false); } catch { /* keep the current workspace */ }
    }
    setSelected(new Set()); setToast('Saved to Supabase');
    if (next) {
      const base = data && patched ? { ...data, leads: data.leads.map(l => l.lead_id === patched!.lead_id ? patched! : l) } : data;
      const nextLead = queueRows(base || undefined).find(l => l.lead_id !== previousId);
      if (nextLead) { setOpenId(nextLead.lead_id); setFromQueue(true); }
      else { setOpenId(null); go('queue'); }
    } else setOpenId(null);
  }
  function toggle(id: string, checked: boolean) { const next = new Set(selected); checked ? next.add(id) : next.delete(id); setSelected(next); }
  function selectAll(checked: boolean, rows: Lead[]) { const next = new Set(selected); rows.slice(0,500).forEach(l => checked ? next.add(l.lead_id) : next.delete(l.lead_id)); setSelected(next); }
  async function bulkAccept() {
    const agentId = (document.getElementById('bulk-agent') as HTMLSelectElement)?.value;
    if (!agentId || !selected.size) return;
    setBusy(true); const { error } = await supabase.rpc('accept_handover', { p: { leadIds: [...selected], agentId } }); setBusy(false);
    if (error) return setToast(error.message); await refresh(false); setSelected(new Set()); setToast('Handover accepted');
  }
  function toggleRoundRobinAgent(id: string) {
    setRoundRobinAgents(current => current.includes(id) ? current.filter(agentId => agentId !== id) : [...current, id]);
  }
  function clearBulkSelection() { setSelected(new Set()); setRoundRobinAgents([]); }
  async function bulkReassign() {
    const roundRobin = viewId === 'new-lqt';
    const agentId = (document.getElementById('bulk-agent') as HTMLSelectElement)?.value;
    if ((!roundRobin && !agentId) || (roundRobin && !roundRobinAgents.length) || !selected.size) return;
    const visibleLeadIds = roundRobin ? filtered(currentView).filter(l => selected.has(l.lead_id)).map(l => l.lead_id) : [];
    const leadIds = roundRobin ? [...visibleLeadIds, ...[...selected].filter(id => !visibleLeadIds.includes(id))] : [...selected];
    setBusy(true);
    const { data: result, error } = roundRobin
      ? await supabase.rpc('round_robin_assign_lqt', { p: { leadIds, agentIds: roundRobinAgents } })
      : await supabase.rpc('reassign_leads', { p: { leadIds, agentId } });
    setBusy(false);
    if (error) return setToast(error.message);
    await refresh(false); clearBulkSelection();
    setToast(roundRobin ? `${result?.assigned ?? leadIds.length} leads assigned round robin across ${roundRobinAgents.length} LQT agent${roundRobinAgents.length === 1 ? '' : 's'}` : 'Leads reassigned');
  }
  async function signOut() { await supabase.auth.signOut(); router.replace('/login'); }

  if (loadError && !data) return <div className="loading"><div className="card"><b>Could not open the CRM</b><p className="error">{loadError}</p><p className="mute">Your Auth account may not be linked to a team member yet.</p><button className="btn" onClick={() => router.replace('/login')}>Back to sign in</button></div></div>;
  if (!data || !me) return <div className="loading">Loading your CRM workspace…</div>;
  const leads = data.leads;
  const countFor = (v: View) => v.id === 'queue' ? queueRows().length : v.filter ? leads.filter(v.filter).length : '';
  const filtered = (v: View) => {
    const q = query.trim().toLowerCase();
    const mineIgnored = v.id === 'tab:Handover Inbox';
    return leads.filter(v.filter || (() => true)).filter(l => {
      if (owner === 'mine' && !mineIgnored && l.current_owner !== me.name) return false;
      if (owner === '__none' && l.current_owner) return false;
      if (owner && !['mine','__none'].includes(owner) && l.current_owner !== owner) return false;
      if (source && l.source !== source) return false;
      if (generation && l.lead_generation !== generation) return false;
      if (registrationFrom && (!l.registration_date || l.registration_date < registrationFrom)) return false;
      if (registrationTo && (!l.registration_date || l.registration_date > registrationTo)) return false;
      if (q && ![l.lead_id,l.business_id,l.business_name,l.merchant_name,l.phone_clean,l.phone,l.email].some(x => String(x || '').toLowerCase().includes(q))) return false;
      return true;
    }).sort(v.final ? (a,b) => String(b.last_status_date).localeCompare(String(a.last_status_date)) : (a,b) => a.priority - b.priority || String(a.next_due_date || '9999').localeCompare(String(b.next_due_date || '9999')));
  };
  const bulkAllowed = isLead || (viewId === 'tab:Handover Inbox' && me.team === 'Incubation');

  return <div className="shell">
    {busy && <div className="busy" />}
    <aside className={`sidebar ${sideOpen ? 'open' : ''}`}>
      <div className="brand">carry<span>bee</span></div><div className="user-line">{me.name}<br />{me.team} · {me.role}</div>
      {views.map((v, i) => <div key={v.id}>{v.group && v.group !== views[i-1]?.group && <div className="nav-group">{v.group}</div>}
        <button className={`nav-btn ${viewId === v.id ? 'active' : ''}`} onClick={() => go(v.id)}><v.icon /><span className="label">{v.title}</span>{countFor(v) !== '' && <span className="count">{countFor(v)}</span>}</button>
      </div>)}
      <div className="nav-group" /><button className="nav-btn" onClick={signOut}><LogOut /><span className="label">Sign out</span></button>
    </aside>
    <header className="topbar">
      <button className="btn icon burger" onClick={() => setSideOpen(!sideOpen)}><Menu /></button>
      <div className="search"><Search /><input className="input" type="search" placeholder="Search business, merchant, phone or ID" value={query} onChange={e => setQuery(e.target.value)} /></div>
      <select className="select" aria-label="Owner" value={owner} onChange={e => setOwner(e.target.value)}><option value="">All owners</option><option value="mine">My leads</option><option value="__none">Unassigned</option>{data.members.filter(m => m.active).map(m => <option key={m.id} value={m.name}>{m.name}</option>)}</select>
      <select className="select" aria-label="Source" value={source} onChange={e => setSource(e.target.value)}><option value="">All sources</option>{data.lists.filter(l => l.category === 'Source').map(l => <option key={l.value}>{l.value}</option>)}</select>
      <select className="select" aria-label="Lead generation" value={generation} onChange={e => setGeneration(e.target.value)}><option value="">New + Old</option><option value="New">New only</option><option value="Old">Old only</option></select>
      <span className="grow" /><span className="sync">Synced {lastSync}</span><ThemeButton />
      <button className="btn icon" title="Refresh" onClick={() => refresh().catch(() => {})}><RefreshCw /></button>
      {isLead && <button className="btn primary" onClick={() => setAddOpen(true)}><Plus />Add lead</button>}
    </header>
    <main className="main">
      {loadError && <div className="banner bad">{loadError}</div>}
      {currentView.special === 'dash' && <Dashboard data={data} me={me} queue={queueRows()} go={go} />}
      {currentView.special === 'queue' && <Queue leads={queueRows()} open={openLead} />}
      {currentView.special === 'flow' && <Flow data={data} go={go} />}
      {currentView.special === 'script' && <><h1 className="page-title">Call script</h1><p className="subtitle">Cover every talking point with each merchant. Script text is backed up with the configuration.</p>{data.scripts.map(p => <div className="card" key={p.point_number}><b>{p.point_number}. {p.talking_point}</b><p style={{ whiteSpace: 'pre-wrap', marginBottom: 0 }}>{p.script_text || <span className="mute">No script yet. Add it in Supabase or the original sheet before migration.</span>}</p></div>)}</>}
      {currentView.special === 'team' && <TeamAdmin members={data.members} settings={data.settings} onChanged={async () => { await refresh(false); }} />}
      {!currentView.special && <><h1 className="page-title">{currentView.title}</h1><p className="subtitle">{filtered(currentView).length} leads{owner === 'mine' && viewId !== 'tab:Handover Inbox' ? ' owned by you' : ''}. {currentView.id === 'new-lqt' ? 'Every Business ID in Old.csv is excluded; select the newer merchants to assign.' : 'New leads are listed before the old book. Click a lead to log a call.'}</p>
        <div className="registration-filters" aria-label="Registration date filters">
          <label>Registration from<input className="input" type="date" aria-label="Registration from" value={registrationFrom} max={registrationTo || undefined} onChange={e => { setRegistrationFrom(e.target.value); setSelected(new Set()); }} /></label>
          <label>Registration to<input className="input" type="date" aria-label="Registration to" value={registrationTo} min={registrationFrom || undefined} onChange={e => { setRegistrationTo(e.target.value); setSelected(new Set()); }} /></label>
          {(registrationFrom || registrationTo) && <button className="btn" onClick={() => { setRegistrationFrom(''); setRegistrationTo(''); setSelected(new Set()); }}>Clear dates</button>}
          {currentView.id === 'new-lqt' && <span className="filter-note">Old.csv exclusion active</span>}
        </div>
        <LeadTable leads={filtered(currentView)} columns={currentView.columns || COLS.all} onOpen={openLead} selected={bulkAllowed ? selected : undefined} onToggle={bulkAllowed ? toggle : undefined} onSelectAll={bulkAllowed ? checked => selectAll(checked, filtered(currentView)) : undefined} />
      </>}
    </main>
    {selected.size > 0 && <div className="bulkbar"><b>{selected.size} selected</b>
      {viewId === 'new-lqt' ? <details className="agent-picker">
        <summary className="select">{roundRobinAgents.length ? `${roundRobinAgents.length} LQT agent${roundRobinAgents.length === 1 ? '' : 's'} selected` : 'Choose LQT agents'}</summary>
        <div className="agent-picker-menu">
          <p className="agent-picker-help">Select in rotation order. Leads will be assigned A → B → C → A…</p>
          {data.members.filter(m => m.active && m.team === 'LQT').map(m => <label className="agent-choice" key={m.id}>
            <input type="checkbox" checked={roundRobinAgents.includes(m.id)} onChange={() => toggleRoundRobinAgent(m.id)} />
            <span>{m.name}</span>{roundRobinAgents.includes(m.id) && <b>#{roundRobinAgents.indexOf(m.id) + 1}</b>}
          </label>)}
          {roundRobinAgents.length > 0 && <p className="agent-order"><b>Rotation:</b> {roundRobinAgents.map((id, index) => <span key={id}>{index + 1}. {data.members.find(m => m.id === id)?.name}</span>)}</p>}
        </div>
      </details> : <select id="bulk-agent" className="select" defaultValue={viewId === 'tab:Handover Inbox' && me.team === 'Incubation' ? me.id : ''}><option value="" disabled>Choose agent</option>{data.members.filter(m => m.active && (viewId !== 'tab:Handover Inbox' || m.team === 'Incubation')).map(m => <option key={m.id} value={m.id}>{m.name} — {m.team}</option>)}</select>}
      {viewId === 'tab:Handover Inbox' && (isLead || me.team === 'Incubation') && <button className="btn primary" onClick={bulkAccept}>Accept handover</button>}
      {isLead && <button className="btn primary" disabled={viewId === 'new-lqt' && !roundRobinAgents.length} onClick={bulkReassign}>{viewId === 'new-lqt' ? roundRobinAgents.length > 1 ? 'Assign round robin' : 'Assign to LQT' : 'Reassign'}</button>}<button className="btn" onClick={clearBulkSelection}>Clear</button>
    </div>}
    {currentLead && <LeadDrawer lead={currentLead} me={me} members={data.members} rules={data.rules} lists={data.lists} scripts={data.scripts} fromQueue={fromQueue} onClose={() => setOpenId(null)} onSaved={saved} />}
    {addOpen && <AddLead members={data.members} lists={data.lists} onClose={() => setAddOpen(false)} onSaved={async () => { await refresh(false); setAddOpen(false); setToast('Lead added'); }} />}
    {toast && <div className="toast">{toast}</div>}
  </div>;
}

function Kpi({ label, value, tone = '', onClick }: { label: string; value: number; tone?: string; onClick: () => void }) {
  return <button className={`kpi ${tone}`} onClick={onClick}><strong>{value}</strong><span>{label}</span></button>;
}
function Dashboard({ data, me, queue, go }: { data: Bootstrap; me: Member; queue: Lead[]; go: (id: string) => void }) {
  const l = data.leads;
  const mine = l.filter(x => x.current_owner === me.name);
  const count = (fn: (x: Lead) => boolean, rows = l) => rows.filter(fn).length;
  const [importing, setImporting] = useState(false);
  const [importMessage, setImportMessage] = useState('');
  async function importOrganic() {
    setImporting(true); setImportMessage('');
    const response = await fetch('/api/admin/import-organic', { method: 'POST' });
    const result = await response.json(); setImporting(false);
    setImportMessage(response.ok ? `Imported ${result.added} leads; skipped ${result.skipped}. Click Refresh to see them.` : result.error);
  }
  return <><h1 className="page-title">Dashboard</h1><p className="subtitle">Hello {me.name}. Live operational metrics from Supabase — no sheet recalculation delay.</p>
    {/lead|admin/i.test(me.role) && <div className="row" style={{ marginBottom: 14 }}><button className="btn primary" disabled={importing} onClick={importOrganic}><Database />{importing ? 'Importing…' : 'Import organic / self-registered leads'}</button>{importMessage && <span className="small mute">{importMessage}</span>}</div>}
    <h2 className="section-title">My work today</h2><div className="kpis">
      <Kpi label="In my call queue" value={queue.length} onClick={() => go('queue')} /><Kpi label="New, not called" value={count(x => x.current_status === 'New', mine)} onClick={() => go('queue')} />
      <Kpi label="Due today" value={count(x => x.due_state === 'Due Today', mine)} tone="warn" onClick={() => go('queue')} /><Kpi label="Overdue" value={count(x => x.due_state === 'Overdue', mine)} tone="bad" onClick={() => go('queue')} />
      <Kpi label="1st contact late" value={count(x => x.first_contact_late === 'Late' && x.is_final === 'No', mine)} tone="bad" onClick={() => go('queue')} /><Kpi label="SLA breached" value={count(x => x.sla_breach === 'Breached', mine)} tone="bad" onClick={() => go('all')} />
    </div><h2 className="section-title">Team</h2><div className="kpis">
      <Kpi label="Open leads" value={count(x => x.is_final === 'No')} onClick={() => go('all')} /><Kpi label="Overdue" value={count(x => x.due_state === 'Overdue')} tone="bad" onClick={() => go('all')} />
      <Kpi label="Due today" value={count(x => x.due_state === 'Due Today')} tone="warn" onClick={() => go('all')} /><Kpi label="Handover inbox" value={count(x => x.current_status === 'Qualified')} onClick={() => go('tab:Handover Inbox')} />
      <Kpi label="Handover call overdue" value={count(x => x.handover_call_state === 'Overdue')} tone="bad" onClick={() => go('tab:Incubation Queue')} /><Kpi label="Trip overdue" value={count(x => x.trip_overdue === 'Overdue')} tone="bad" onClick={() => go('tab:Incubation Queue')} />
      <Kpi label="In care period" value={count(x => x.current_status === '1st Trip Complete')} onClick={() => go('tab:Care Period')} /><Kpi label="Old book open" value={count(x => x.lead_generation === 'Old' && x.stage === 'LQT' && x.is_final === 'No')} onClick={() => go('old')} /><Kpi label="New to LQT" value={count(x => x.lead_generation === 'New' && x.stage === 'LQT' && x.is_final === 'No')} tone="warn" onClick={() => go('new-gen')} />
      <Kpi label="Missing Business ID" value={count(x => x.missing_business_id === 'Missing')} tone="warn" onClick={() => go('nobid')} /><Kpi label="Unassigned" value={count(x => !x.current_owner)} tone="warn" onClick={() => go('all')} />
    </div><h2 className="section-title">By agent</h2><div className="table-wrap"><table><thead><tr><th>Agent</th><th>Team</th><th>Open</th><th>Queue</th><th>New</th><th>Due today</th><th>Overdue</th><th>SLA breached</th><th>In care</th></tr></thead><tbody>
      {data.members.filter(m => m.active && m.team !== 'Management').map(m => { const rows = l.filter(x => x.current_owner === m.name); return <tr key={m.id}><td><b>{m.name}</b></td><td>{m.team}</td><td>{count(x => x.is_final === 'No', rows)}</td><td>{count(x => x.priority <= 3, rows)}</td><td>{count(x => x.current_status === 'New', rows)}</td><td>{count(x => x.due_state === 'Due Today', rows)}</td><td>{count(x => x.due_state === 'Overdue', rows)}</td><td>{count(x => x.sla_breach === 'Breached', rows)}</td><td>{count(x => x.current_status === '1st Trip Complete', rows)}</td></tr>; })}
    </tbody></table></div></>;
}
function Queue({ leads, open }: { leads: Lead[]; open: (id: string, queue: boolean) => void }) {
  const labels: Record<number,string> = { 0: 'Handover call overdue', 1: 'Overdue', 2: 'New lead', 3: 'Due today' };
  return <><h1 className="page-title">My call queue</h1><p className="subtitle">Your leads that need a call now, ordered by the same priority rules as the original CRM.</p>
    {!leads.length ? <div className="card empty">Your queue is clear. Check Follow Up and Care Period for upcoming work.</div> : <><button className="btn primary" style={{ marginBottom: 12 }} onClick={() => open(leads[0].lead_id, true)}>Start with the first call<ChevronRight /></button><LeadTable leads={leads} columns={['lead_id','business_name','phone_clean','current_status','lqt_touches','next_due_date','due_state','alert']} onOpen={id => open(id, true)} /><p className="table-note">Priority: {leads.slice(0,10).map(l => `${l.lead_id} (${labels[l.priority] || 'Upcoming'})`).join(' · ')}{leads.length > 10 ? '…' : ''}</p></>}
  </>;
}
function Flow({ data, go }: { data: Bootstrap; go: (id: string) => void }) {
  const s = (key: string) => setting(data.settings,key); const count = (tab: string) => data.leads.filter(l => l.tab === tab).length;
  const Step = ({ title, text, n, view }: { title: string; text: string; n: number; view: string }) => <button className="step" onClick={() => go(view)}><b>{title}</b><span>{text}</span><strong>{n}</strong></button>;
  return <><h1 className="page-title">How it works</h1><p className="subtitle">Lead movement and timing rules, now calculated directly in Postgres.</p><div className="lanes">
    <div className="lane"><h3>1. Supabase is the source of truth</h3><div className="steps"><Step title="Leads" text="TL assigns leads; every read and write is live in Postgres." n={data.leads.length} view="all" /><Step title="Old follow-ups" text="Migrated legacy calls remain in the audit history." n={data.leads.filter(l => l.has_legacy === 'Yes' && l.is_final === 'No').length} view="old" /></div></div>
    <div className="lane"><h3>2. Lead Qualification Team (LQT)</h3><div className="steps"><Step title="New Leads" text={`1st call within ${s('FIRST_CONTACT_DAYS')} day of assignment`} n={count('New Leads')} view="tab:New Leads" /><Step title="CNR" text={`${s('CNR_MAX')} CNRs become Silent Leads`} n={count('CNR')} view="tab:CNR" /><Step title="Follow Up" text={`FU1 day ${s('FU1_DAYS')} (max ${s('FU1_MAX')}); FU2 day ${s('FU2_DAYS')} (max ${s('FU2_MAX')})`} n={count('Follow Up')} view="tab:Follow Up" /><Step title="Qualified" text="Profile, talking points, booked call and handover note" n={count('Handover Inbox')} view="tab:Handover Inbox" /></div><p className="mute small">Final status or Qualified within {s('FINAL_SLA_DAYS')} days of assignment.</p></div>
    <div className="lane"><h3>3. Incubation</h3><div className="steps"><Step title="Handover Inbox" text={`Call within ${s('HANDOVER_CALL_MIN')} minutes of the booked slot`} n={count('Handover Inbox')} view="tab:Handover Inbox" /><Step title="Incubation Queue" text={`1st trip within ${s('TRIP_DAYS')} days of accepting`} n={count('Incubation Queue')} view="tab:Incubation Queue" /><Step title="Care Period" text={`${s('CARE_DAYS')} days from first trip`} n={count('Care Period')} view="tab:Care Period" /><Step title="Care Completed" text="Automatic after care period" n={count('Care Completed')} view="tab:Care Completed" /></div></div>
  </div></>;
}

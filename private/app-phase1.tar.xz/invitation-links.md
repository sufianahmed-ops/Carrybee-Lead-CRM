# Carrybee CRM invitation links

**Private:** each link grants access to its named account. Send each link only to the matching work email. Links expire according to Supabase Auth policy and should be used once to set a password.

| Full name | Work email | Team | Role | Invitation |
|---|---|---|---|---|
| Eyaliduzzaman Shunucki | eyali.duzzaman@carrybee.com | Incubation | Agent | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=72baafc30a681a350793bda0520eec46a4d084b6d06497f10e5c8d3b&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |
| Md. shariful Islam Tonoy | tonoy.islam@carrybee.com | LQT | Agent | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=b5838e625b16bfd2e94280d0eb8b3bff2e6821423c940fc51efecd3f&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |
| MD. Zahin Rahman | zahin.rahman@carrybee.com | LQT | Agent | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=d08eb14f0e3843fbf1b3417d941131068eae76dfafcc9f54727194a0&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |
| MD.Ebrahim Emu | ibrahim.emu@carrybee.com | Incubation | Agent | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=83bcea3013c8b40ba75274de92c00aad8872286f3cfb66633bd6b8c6&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |
| Md.Mahmudul Hasan | mahmudul.hasan@carrybee.com | Incubation | Agent | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=a57595af4f19dad539a2189b40ab41f0e78e0d679e799b44527451c4&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |
| Mohammad Sazzad Haider | sazzad.haider@carrybee.com | Incubation | Lead | [Open invitation](https://mpxvegyzpybnipokztbz.supabase.co/auth/v1/verify?token=59e9a7936f48e42e1a2f1c5214cf162b0059fb37945eafc99e646dfa&type=invite&redirect_to=https://carrybee-lead-crm.vercel.app/auth/callback) |

After opening a link, the recipient should set their password and then sign in at https://carrybee-lead-crm.vercel.app/login.

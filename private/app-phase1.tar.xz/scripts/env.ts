import { config } from 'dotenv';
config({ path: '.env.local' });
config();

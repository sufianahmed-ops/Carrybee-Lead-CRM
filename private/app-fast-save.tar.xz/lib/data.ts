import type { SupabaseClient } from '@supabase/supabase-js';
import type { Bootstrap, Lead } from './types';

async function allRows<T>(query: any): Promise<T[]> {
  const pageSize = 1000;
  const output: T[] = [];
  for (let from = 0; ; from += pageSize) {
    const { data, error } = await query.range(from, from + pageSize - 1);
    if (error) throw error;
    output.push(...(data || []));
    if (!data || data.length < pageSize) return output;
  }
}

export async function loadBootstrap(supabase: SupabaseClient): Promise<Bootstrap> {
  const [leads, members, rules, settings, lists, scripts] = await Promise.all([
    allRows<Lead>(supabase.from('lead_details').select('*').order('lead_id')),
    allRows(supabase.from('team_members').select('*').order('name')),
    allRows(supabase.from('status_rules').select('*').order('status')),
    allRows(supabase.from('app_settings').select('*').order('key')),
    allRows(supabase.from('list_values').select('*').order('sort_order')),
    allRows(supabase.from('call_scripts').select('*').order('point_number')),
  ]);
  return { leads, members: members as any, rules: rules as any, settings: settings as any, lists: lists as any, scripts: scripts as any };
}

/**
 * Re-read a single lead from the computed view so all derived columns
 * (due state, priority, alerts, care dates, touch counts) stay authoritative
 * while the rest of the workspace is left untouched.
 */
export async function loadOneLead(supabase: SupabaseClient, leadId: string): Promise<Lead | null> {
  const { data, error } = await supabase.from('lead_details').select('*').eq('lead_id', leadId).limit(1);
  if (error) throw error;
  return (data?.[0] as Lead) || null;
}

export function setting(settings: { key: string; value: string }[], key: string, fallback = '') {
  return settings.find(s => s.key === key)?.value ?? fallback;
}
